import 'package:flutter/material.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';

final smallBtn = FilledButton.styleFrom(
    minimumSize: const Size(0, 36), padding: const EdgeInsets.symmetric(horizontal: 14));

class NNLogo extends StatelessWidget {
  const NNLogo({super.key, this.size = 84});
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            border: Border.all(color: kRed, width: size / 22)),
        child: Text('NN',
            style: TextStyle(color: kRed, fontSize: size * .36, fontWeight: FontWeight.w900)),
      );
}

class NNCard extends StatelessWidget {
  const NNCard(
      {super.key,
      required this.child,
      this.padding = const EdgeInsets.all(14),
      this.borderColor,
      this.onTap});
  final Widget child;
  final EdgeInsets padding;
  final Color? borderColor;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => Material(
        color: kSurface,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(color: borderColor ?? kBorder)),
        child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child)),
      );
}

class WideButton extends StatelessWidget {
  const WideButton(this.label, this.onPressed,
      {super.key, this.outlined = false, this.danger = false});
  final String label;
  final VoidCallback? onPressed;
  final bool outlined;
  final bool danger;
  @override
  Widget build(BuildContext context) {
    final c = danger ? kRed : kOrange;
    final text = Text(label, style: const TextStyle(fontWeight: FontWeight.w700));
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: outlined
          ? OutlinedButton(
              onPressed: onPressed,
              style: OutlinedButton.styleFrom(foregroundColor: c, side: BorderSide(color: c)),
              child: text)
          : FilledButton(
              onPressed: onPressed,
              style: FilledButton.styleFrom(
                  backgroundColor: c, foregroundColor: danger ? Colors.white : Colors.black),
              child: text),
    );
  }
}

class FoodImage extends StatelessWidget {
  const FoodImage(this.path, {super.key, this.w = 64, this.h = 64, this.radius = 12});
  final String? path;
  final double w;
  final double h;
  final double radius;

  Widget get _placeholder => Container(
      width: w, height: h, color: kBorder, child: const Icon(Icons.restaurant, color: kOrange));

  @override
  Widget build(BuildContext context) {
    final p = path;
    Widget child;
    if (p == null) {
      child = _placeholder;
    } else if (p.startsWith('http')) {
      // Picture address saved by the manager (menu_items.image_url).
      child = Image.network(p,
          width: w, height: h, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _placeholder);
    } else {
      child = Image.asset(p, width: w, height: h, fit: BoxFit.cover);
    }
    return ClipRRect(borderRadius: BorderRadius.circular(radius), child: child);
  }
}

class QtyStepper extends StatelessWidget {
  const QtyStepper(this.qty, this.onMinus, this.onPlus, {super.key});
  final int qty;
  final VoidCallback onMinus;
  final VoidCallback onPlus;
  Widget _btn(IconData icon, VoidCallback onTap, bool filled) => InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: filled ? kOrange : kBorder),
          child: Icon(icon, size: 18, color: filled ? Colors.black : Colors.white),
        ),
      );
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        _btn(Icons.remove, onMinus, false),
        Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text('$qty', style: const TextStyle(fontWeight: FontWeight.w700))),
        _btn(Icons.add, onPlus, true),
      ]);
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key, this.action, this.onAction});
  final String title;
  final String? action;
  final VoidCallback? onAction;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 10),
        child: Row(children: [
          Expanded(
              child: Text(title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
          if (action != null)
            GestureDetector(
                onTap: onAction,
                child: Text(action!, style: const TextStyle(color: kOrange, fontSize: 12))),
        ]),
      );
}

class CategoryChips extends StatelessWidget {
  const CategoryChips({super.key, required this.selected, required this.onSelected});
  final String selected;
  final ValueChanged<String> onSelected;
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 42,
        child: ListView(scrollDirection: Axis.horizontal, children: [
          for (final c in ['All', ...store.categoryNames])
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(c),
                selected: selected == c,
                selectedColor: kOrange,
                showCheckmark: false,
                labelStyle: TextStyle(
                    color: selected == c ? Colors.black : Colors.white,
                    fontWeight: FontWeight.w600),
                onSelected: (_) => onSelected(c),
              ),
            ),
        ]),
      );
}

Color statusColor(OrderStatus s) {
  switch (s) {
    case OrderStatus.received:
      return kYellow;
    case OrderStatus.preparing:
      return kOrange;
    case OrderStatus.ready:
      return kGreen;
    case OrderStatus.collected:
      return kMuted;
    case OrderStatus.cancelled:
      return kRed;
  }
}

class StatusChip extends StatelessWidget {
  const StatusChip(this.status, {super.key});
  final OrderStatus status;
  @override
  Widget build(BuildContext context) {
    final c = statusColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: c.withAlpha(40), borderRadius: BorderRadius.circular(6)),
      child: Text(status.label.toUpperCase(),
          style: TextStyle(color: c, fontSize: 10, fontWeight: FontWeight.w800)),
    );
  }
}

/// Order total. Prices are what the web app shows (no VAT line, no delivery fee: pickup only,
/// pay cash or card at the counter, as agreed in the SRS).
class TotalsBlock extends StatelessWidget {
  const TotalsBlock({super.key, required this.total});
  final double total;

  @override
  Widget build(BuildContext context) => Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Total Amount', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          Text(money(total),
              style: const TextStyle(color: kOrange, fontSize: 18, fontWeight: FontWeight.w800)),
        ]),
        const SizedBox(height: 4),
        const Align(
            alignment: Alignment.centerLeft,
            child: Text('Pay at the counter when you collect (cash or card).',
                style: TextStyle(color: kMuted, fontSize: 12))),
      ]);
}

/// Shown instead of a list while the menu is loading or could not be loaded.
class MenuStatus extends StatelessWidget {
  const MenuStatus({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          if (store.menuLoading) {
            return const Padding(
                padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator()));
          }
          return Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.cloud_off, size: 48, color: kMuted),
              const SizedBox(height: 10),
              Text(store.menuError ?? 'The menu is empty right now.',
                  textAlign: TextAlign.center, style: const TextStyle(color: kMuted)),
              const SizedBox(height: 14),
              OutlinedButton(onPressed: store.refreshMenu, child: const Text('Try again')),
            ]),
          );
        },
      );
}

/// One dish row with an Add button that turns into a quantity stepper.
class DishTile extends StatelessWidget {
  const DishTile(this.item, {super.key});
  final MenuItem item;
  @override
  Widget build(BuildContext context) {
    final qty = store.qtyOf(item);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: NNCard(
        padding: const EdgeInsets.all(10),
        child: Row(children: [
          FoodImage(item.image, w: 70, h: 70),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              Text(item.description,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: kMuted, fontSize: 12)),
              const SizedBox(height: 4),
              Text(money(item.price),
                  style: const TextStyle(color: kOrange, fontWeight: FontWeight.w700)),
            ]),
          ),
          const SizedBox(width: 8),
          qty == 0
              ? FilledButton(
                  style: smallBtn,
                  onPressed: () => store.addToCart(item),
                  child: const Text('Add'))
              : QtyStepper(qty, () => store.removeOne(item), () => store.addToCart(item)),
        ]),
      ),
    );
  }
}

/// Rebuilds every second (live timers).
class Tick extends StatelessWidget {
  const Tick({super.key, required this.builder});
  final Widget Function(BuildContext context) builder;
  @override
  Widget build(BuildContext context) => StreamBuilder<int>(
        stream: Stream.periodic(const Duration(seconds: 1), (i) => i),
        builder: (context, _) => builder(context),
      );
}

class StaffHeader extends StatelessWidget {
  const StaffHeader({super.key, required this.kicker, required this.title, this.trailing});
  final String kicker;
  final String title;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Row(children: [
          Container(
            width: 36,
            height: 36,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: kOrange, borderRadius: BorderRadius.circular(8)),
            child: const Text('N',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(kicker,
                  style: const TextStyle(color: kMuted, fontSize: 10, letterSpacing: 1.2)),
              Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            ]),
          ),
          if (trailing != null) trailing!,
        ]),
      );
}
