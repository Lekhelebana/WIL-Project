/// Same Supabase project the ASP.NET web app uses (see NamaNameng ASP appsettings / user secrets).
///
/// Only the public URL and the **anon** key belong here. The anon key is meant to ship inside
/// apps: Row Level Security in the database (supabase/01_schema.sql) is what protects the data.
/// NEVER put the database password or the `service_role` key in this app.
const supabaseUrl = 'https://qmcwfnupigrpkmtommcd.supabase.co';
const supabaseAnonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFtY3dmbnVwaWdycGttdG9tbWNkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc2NzgyMzgsImV4cCI6MjEwMzI1NDIzOH0.Ub3ac-ZtHVC9AXyo60lB20FiPlZ3J7FT46uqA1v98KY';
