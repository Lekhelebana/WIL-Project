import 'package:flutter/material.dart';

const kBg = Color(0xFF0B0B0C);
const kSurface = Color(0xFF16161A);
const kBorder = Color(0xFF26262C);
const kOrange = Color(0xFFFF7A1A);
const kGreen = Color(0xFF34C77B);
const kYellow = Color(0xFFF5B83D);
const kRed = Color(0xFFEF4B4B);
const kMuted = Color(0xFF9A9AA3);

ThemeData buildTheme() {
  final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(12));
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: kBg,
    colorScheme: const ColorScheme.dark(
        primary: kOrange, onPrimary: Colors.black, surface: kSurface, error: kRed),
    appBarTheme: const AppBarTheme(backgroundColor: kBg, elevation: 0, centerTitle: true),
    filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
            backgroundColor: kOrange, foregroundColor: Colors.black, shape: shape)),
    outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
            foregroundColor: kOrange, side: const BorderSide(color: kOrange), shape: shape)),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kSurface,
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: kBorder)),
    ),
    navigationBarTheme: NavigationBarThemeData(
        backgroundColor: kSurface, indicatorColor: kOrange.withAlpha(60)),
    segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
            selectedBackgroundColor: kOrange, selectedForegroundColor: Colors.black)),
  );
}
