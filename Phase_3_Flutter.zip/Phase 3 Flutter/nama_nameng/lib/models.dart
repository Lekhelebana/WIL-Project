// Data classes that mirror the shared Supabase schema (supabase/01_schema.sql in the ASP.NET solution).

const int kTargetMinutes = 15; // staff timer turns red after this
const int kMaxQty = 20; // matches the order_items check constraint

double r2(double v) => (v * 100).round() / 100;
String money(double v) => 'R${v.toStringAsFixed(2)}';
String mmss(Duration d) =>
    '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
String ago(DateTime t) {
  final m = DateTime.now().difference(t).inMinutes;
  return m < 1 ? 'just now' : (m < 60 ? '$m min ago' : '${m ~/ 60} h ago');
}

double _num(Object? v) => v is num ? v.toDouble() : double.tryParse('$v') ?? 0;

/// Bundled pictures, matched by dish name (first keyword hit wins), then by category.
/// Used for items that have no image_url in the database.
const _dishImages = <MapEntry<List<String>, String>>[
  MapEntry(['wing'], 'assets/images/chicken_wings.jpg'),
  MapEntry(['chicken', 'quarter'], 'assets/images/chicken_quarter.jpg'),
  MapEntry(['lamb', 'chop'], 'assets/images/lamb_chops.jpg'),
  MapEntry(['rib'], 'assets/images/beef_ribs.jpg'),
  MapEntry(['wors', 'boerewors', 'sausage'], 'assets/images/wors.jpg'),
  MapEntry(['morogo', 'spinach'], 'assets/images/morogo.jpg'),
  MapEntry(['chakalaka'], 'assets/images/chakalaka.jpg'),
  MapEntry(['pap', 'phutu'], 'assets/images/pap.jpg'),
  MapEntry(['chip', 'fries'], 'assets/images/chips.jpg'),
  MapEntry(['ginger'], 'assets/images/ginger_beer.jpg'),
  MapEntry(['water'], 'assets/images/still_water.jpg'),
  MapEntry(['soft drink', 'cola', 'coke', 'fanta', 'sprite', 'cooldrink', 'cold drink', 'soda'],
      'assets/images/soft_drink.jpg'),
];

/// Picture for a dish: by its name first, then a generic one for its category.
String? imageFor(String category, [String name = '']) {
  final n = name.toLowerCase();
  if (n.isNotEmpty) {
    for (final e in _dishImages) {
      if (e.key.any(n.contains)) return e.value;
    }
  }
  final c = category.toLowerCase();
  if (c.contains('grill')) return 'assets/images/ribs.jpg';
  if (c.contains('side')) return 'assets/images/fries.jpg';
  if (c.contains('drink') || c.contains('beverage')) return 'assets/images/soft_drink.jpg';
  return null;
}

// ---------------------------------------------------------------- roles & statuses
class Roles {
  static const customer = 'Customer';
  static const staff = 'Staff';
  static const manager = 'Manager';
}

/// Values stored in orders.status. Same list as the web app.
enum OrderStatus { received, preparing, ready, collected, cancelled }

extension OrderStatusX on OrderStatus {
  String get db => const {
        OrderStatus.received: 'Received',
        OrderStatus.preparing: 'Preparing',
        OrderStatus.ready: 'Ready',
        OrderStatus.collected: 'Collected',
        OrderStatus.cancelled: 'Cancelled',
      }[this]!;

  String get label => this == OrderStatus.received ? 'New' : db;

  bool get isOpen =>
      this == OrderStatus.received || this == OrderStatus.preparing || this == OrderStatus.ready;

  static OrderStatus fromDb(String? s) =>
      OrderStatus.values.firstWhere((v) => v.db == s, orElse: () => OrderStatus.received);
}

// ---------------------------------------------------------------- profile
class Profile {
  Profile({
    required this.id,
    required this.fullName,
    required this.email,
    required this.phone,
    required this.role,
    required this.isActive,
    this.isAnonymous = false,
  });
  final String id;
  String fullName;
  final String email;
  String phone;
  final String role;
  final bool isActive;

  /// True for guest sessions (Supabase anonymous sign-in). Guests have a profile row but no email.
  final bool isAnonymous;

  bool get isStaff => role == Roles.staff || role == Roles.manager;
  bool get isManager => role == Roles.manager;

  factory Profile.fromJson(Map<String, dynamic> j, {bool isAnonymous = false}) => Profile(
        id: j['id'] as String,
        fullName: (j['full_name'] as String?) ?? '',
        email: (j['email'] as String?) ?? '',
        phone: (j['phone'] as String?) ?? '',
        role: (j['role'] as String?) ?? Roles.customer,
        isActive: (j['is_active'] as bool?) ?? true,
        isAnonymous: isAnonymous,
      );
}

// ---------------------------------------------------------------- menu
class MenuCategory {
  const MenuCategory({required this.id, required this.name, required this.sortOrder});
  final int id;
  final String name;
  final int sortOrder;

  factory MenuCategory.fromJson(Map<String, dynamic> j) => MenuCategory(
      id: j['id'] as int, name: j['name'] as String, sortOrder: (j['sort_order'] as int?) ?? 0);
}

class MenuItem {
  MenuItem({
    required this.id,
    required this.categoryId,
    required this.category,
    required this.name,
    required this.price,
    this.description = '',
    this.imageUrl,
    this.available = true,
  });
  final int id;
  int categoryId;
  String category; // category name, filled in by the store
  String name;
  double price;
  String description;
  String? imageUrl;
  bool available;

  /// Network picture from the database, or a bundled fallback picture by category.
  String? get image => (imageUrl != null && imageUrl!.isNotEmpty) ? imageUrl : imageFor(category, name);

  factory MenuItem.fromJson(Map<String, dynamic> j, Map<int, String> categoryNames) {
    final cid = j['category_id'] as int;
    return MenuItem(
      id: j['id'] as int,
      categoryId: cid,
      category: categoryNames[cid] ?? '',
      name: j['name'] as String,
      description: (j['description'] as String?) ?? '',
      price: _num(j['price']),
      imageUrl: j['image_url'] as String?,
      available: (j['is_available'] as bool?) ?? true,
    );
  }

  @override
  bool operator ==(Object other) => other is MenuItem && other.id == id;
  @override
  int get hashCode => id.hashCode;
}

class CartLine {
  CartLine(this.item, this.qty);
  final MenuItem item;
  int qty;
  double get total => item.price * qty;
}

// ---------------------------------------------------------------- orders
class OrderLine {
  const OrderLine(this.name, this.price, this.qty, {this.menuItemId});
  final String name;
  final double price;
  final int qty;
  final int? menuItemId;
  double get total => price * qty;
}

class Order {
  Order({
    required this.id,
    required this.number,
    required this.lines,
    required this.placedAt,
    required this.total,
    this.status = OrderStatus.received,
    this.customerName = 'Guest',
    this.customerId,
    this.note = '',
  });
  final int id;
  final String number; // NN-1001 ...
  final List<OrderLine> lines;
  final DateTime placedAt;
  final double total;
  OrderStatus status;
  final String customerName;
  final String? customerId;
  final String note;

  String get summary => lines.map((l) => '${l.qty}× ${l.name}').join(', ');

  /// Row from `orders` with `order_items(menu_item_id, quantity, price_at_order, menu_items(name))` embedded.
  factory Order.fromJson(Map<String, dynamic> j) {
    final items = (j['order_items'] as List?) ?? const [];
    return Order(
      id: j['id'] as int,
      number: (j['order_number'] as String?) ?? '#${j['id']}',
      status: OrderStatusX.fromDb(j['status'] as String?),
      total: _num(j['total']),
      customerName: (j['customer_name'] as String?) ?? 'Guest',
      customerId: j['customer_id'] as String?,
      note: (j['notes'] as String?) ?? '',
      placedAt: DateTime.parse(j['created_at'] as String).toLocal(),
      lines: [
        for (final i in items.cast<Map<String, dynamic>>())
          OrderLine(
            ((i['menu_items'] as Map?)?['name'] as String?) ?? 'Item',
            _num(i['price_at_order']),
            (i['quantity'] as num).toInt(),
            menuItemId: (i['menu_item_id'] as num?)?.toInt(),
          ),
      ],
    );
  }
}
