import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'screens/welcome.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Same Supabase project as the ASP.NET web app: same users, menu and orders.
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  await store.init();
  runApp(const NamaNamengApp());
}

class NamaNamengApp extends StatelessWidget {
  const NamaNamengApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Nama Nameng',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const WelcomeScreen(),
      );
}
