import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'auth.dart';
import 'customer.dart';
import 'staff.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  void _go(BuildContext context, Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              const SizedBox(height: 8),
              const NNLogo(size: 90),
              const SizedBox(height: 12),
              const Text('NAMA NAMENG',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
              const Text('FAST BITES • GOOD NIGHTS',
                  style: TextStyle(color: kOrange, fontSize: 12, letterSpacing: 2)),
              const SizedBox(height: 16),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset('assets/images/ribs.jpg',
                      width: double.infinity, fit: BoxFit.cover),
                ),
              ),
              const SizedBox(height: 16),
              WideButton('Get Started', () {
                if (store.staff != null) return _go(context, const StaffShell());
                if (store.user != null) return _go(context, const CustomerShell());
                _go(context, const AuthScreen());
              }),
              const SizedBox(height: 10),
              WideButton('Explore Menu', () => _go(context, const CustomerShell()),
                  outlined: true),
            ]),
          ),
        ),
      );
}
