import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'auth.dart';
import 'customer.dart';

// ---------------------------------------------------------------- Checkout
class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: store.user?.fullName ?? '');
  final _note = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _place() async {
    if (store.cart.isEmpty || _busy) return;
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      final o = await store.placeOrder(name: _name.text, note: _note.text);
      if (!mounted) return;
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => PaymentConfirmedScreen(order: o)));
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> _signIn() async {
    final ok = await Navigator.push<bool>(
        context, MaterialPageRoute(builder: (_) => const AuthScreen(returnOnSuccess: true)));
    if (ok == true && mounted) setState(() => _name.text = store.user?.fullName ?? _name.text);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Checkout')),
        body: SafeArea(
          child: ListenableBuilder(
            listenable: store,
            builder: (context, _) => Form(
              key: _form,
              child: ListView(padding: const EdgeInsets.all(16), children: [
                const Text('YOUR BASKET',
                    style: TextStyle(color: kMuted, fontSize: 11, letterSpacing: 1.2)),
                const SizedBox(height: 8),
                for (final l in store.cart)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text('${l.qty}x ${l.item.name}'),
                      Text(money(l.total), style: const TextStyle(fontWeight: FontWeight.w600)),
                    ]),
                  ),
                const Divider(color: kBorder, height: 24),
                TotalsBlock(total: store.total),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _name,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                      labelText: 'Your name', helperText: 'So we can call you when your order is ready'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter your name' : null,
                ),
                if (store.user == null)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                        onPressed: _signIn, child: const Text('Have an account? Sign in (optional)')),
                  ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _note,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'Note for the kitchen (optional)'),
                ),
                const SizedBox(height: 16),
                const NNCard(
                  child: Row(children: [
                    Icon(Icons.storefront, color: kOrange),
                    SizedBox(width: 12),
                    Expanded(
                        child: Text(
                            'Collect at the counter and pay there with cash or card. There is no online payment or delivery.',
                            style: TextStyle(fontSize: 13))),
                  ]),
                ),
                const SizedBox(height: 20),
                WideButton(_busy ? 'Placing order...' : 'Place order  ${money(store.total)}',
                    (store.cart.isEmpty || _busy) ? null : _place),
              ]),
            ),
          ),
        ),
      );
}

// ---------------------------------------------------------------- Confirmed
class PaymentConfirmedScreen extends StatelessWidget {
  const PaymentConfirmedScreen({super.key, required this.order});
  final Order order;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Expanded(
                child: ListView(children: [
                  const SizedBox(height: 20),
                  const Center(
                    child: CircleAvatar(
                        radius: 38,
                        backgroundColor: kOrange,
                        child: Icon(Icons.check, size: 44, color: Colors.black)),
                  ),
                  const SizedBox(height: 14),
                  const Center(
                      child: Text('Order Received!',
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800))),
                  const SizedBox(height: 6),
                  const Center(
                    child: Text(
                        'Thank you! The kitchen has your order.\nPay at the counter when you collect it.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: kMuted)),
                  ),
                  const SizedBox(height: 20),
                  NNCard(
                    child: Column(children: [
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        const Text('Order ID', style: TextStyle(color: kMuted)),
                        Text('#${order.number}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      ]),
                      const SizedBox(height: 6),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        const Text('Total to pay', style: TextStyle(color: kMuted)),
                        Text(money(order.total),
                            style: const TextStyle(color: kOrange, fontWeight: FontWeight.w800)),
                      ]),
                    ]),
                  ),
                  const SectionTitle('Order summary'),
                  NNCard(
                    child: Column(children: [
                      for (final l in order.lines)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                            Text('${l.qty}x ${l.name}'),
                            Text(money(l.total)),
                          ]),
                        ),
                      const Divider(color: kBorder),
                      TotalsBlock(total: order.total),
                    ]),
                  ),
                ]),
              ),
              WideButton('Track Your Order', () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => TrackOrderScreen(orderId: order.id)))),
              const SizedBox(height: 10),
              WideButton('Return to Home', () => Navigator.pushAndRemoveUntil(
                  context, MaterialPageRoute(builder: (_) => const CustomerShell()), (r) => false),
                  outlined: true),
            ]),
          ),
        ),
      );
}

// ---------------------------------------------------------------- Track
class TrackOrderScreen extends StatelessWidget {
  const TrackOrderScreen({super.key, required this.orderId});
  final int orderId;
  static const _flow = [
    OrderStatus.received,
    OrderStatus.preparing,
    OrderStatus.ready,
    OrderStatus.collected,
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Track Order')),
        body: SafeArea(
          child: ListenableBuilder(
            listenable: store,
            builder: (context, _) {
              final o = store.orderById(orderId);
              if (o == null) {
                return const Center(child: CircularProgressIndicator());
              }
              final idx = _flow.indexOf(o.status); // -1 when cancelled
              final titles = ['Order received', 'Preparing food', 'Ready for pickup', 'Collected'];
              final subs = [
                'We have your order • ${ago(o.placedAt)}',
                'Your food is on the grill',
                'Come to the counter and show #${o.number}',
                'Enjoy your meal!',
              ];
              final Color bannerColor;
              final String bannerText;
              if (o.status == OrderStatus.cancelled) {
                bannerColor = kRed;
                bannerText = 'This order was cancelled. Please contact the counter or order again.';
              } else if (o.status == OrderStatus.collected) {
                bannerColor = kGreen;
                bannerText = 'Collected — enjoy!';
              } else if (o.status == OrderStatus.ready) {
                bannerColor = kGreen;
                bannerText = 'Your order is ready. Collect it at the counter.';
              } else {
                bannerColor = kOrange;
                bannerText = 'We will have it ready soon. This page updates by itself.';
              }
              return ListView(padding: const EdgeInsets.all(16), children: [
                Text('Order  #${o.number}',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                      color: bannerColor.withAlpha(35),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: bannerColor)),
                  child: Row(children: [
                    Icon(Icons.schedule, color: bannerColor, size: 18),
                    const SizedBox(width: 8),
                    Expanded(child: Text(bannerText, style: TextStyle(color: bannerColor))),
                  ]),
                ),
                const SizedBox(height: 18),
                if (idx >= 0)
                  for (var i = 0; i < _flow.length; i++)
                    _Step(titles[i], subs[i], done: idx >= i, last: i == _flow.length - 1),
                const SectionTitle('Order summary'),
                NNCard(
                  child: Column(children: [
                    for (final l in o.lines)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text('${l.qty}x ${l.name}'),
                          Text(money(l.total)),
                        ]),
                      ),
                    const Divider(color: kBorder),
                    TotalsBlock(total: o.total),
                  ]),
                ),
                if (!o.status.isOpen) ...[
                  const SizedBox(height: 16),
                  WideButton('Order again', () {
                    final n = store.reorder(o);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(n == 0
                            ? 'Those items are not available right now.'
                            : 'Items from #${o.number} added to your cart.')));
                    if (n > 0) {
                      Navigator.pushAndRemoveUntil(context,
                          MaterialPageRoute(builder: (_) => const CustomerShell()), (r) => false);
                    }
                  }, outlined: true),
                ],
              ]);
            },
          ),
        ),
      );
}

class _Step extends StatelessWidget {
  const _Step(this.title, this.sub, {required this.done, required this.last});
  final String title;
  final String sub;
  final bool done;
  final bool last;
  @override
  Widget build(BuildContext context) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Column(children: [
          Icon(done ? Icons.check_circle : Icons.radio_button_unchecked,
              color: done ? kOrange : kMuted),
          if (!last) Container(width: 2, height: 34, color: done ? kOrange : kBorder),
        ]),
        const SizedBox(width: 12),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(top: 2, bottom: last ? 0 : 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title,
                  style: TextStyle(fontWeight: FontWeight.w700, color: done ? Colors.white : kMuted)),
              Text(sub, style: const TextStyle(color: kMuted, fontSize: 12)),
            ]),
          ),
        ),
      ]);
}
