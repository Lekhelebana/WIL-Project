import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'customer.dart';
import 'forgot_password.dart';
import 'staff.dart';

/// One sign-in screen for both dashboards: Customer or Staff.
class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, this.returnOnSuccess = false});

  /// When true (e.g. opened from checkout) a successful customer sign-in pops back.
  final bool returnOnSuccess;
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _form = GlobalKey<FormState>();
  int _role = 0; // 0 = customer, 1 = staff
  bool _register = false;
  bool _hide = true;
  bool _busy = false;
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _confirm = TextEditingController();

  @override
  void dispose() {
    for (final c in [_name, _phone, _email, _pass, _confirm]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _required(String? v) => (v == null || v.trim().isEmpty) ? 'Required' : null;

  Widget _field(TextEditingController c, String label,
      {bool obscure = false,
      TextInputType? type,
      String? Function(String?)? validator,
      Widget? suffix}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        obscureText: obscure,
        keyboardType: type,
        decoration: InputDecoration(labelText: label, suffixIcon: suffix),
        validator: validator ?? _required,
      ),
    );
  }

  Widget get _eye => IconButton(
      icon: Icon(_hide ? Icons.visibility_off : Icons.visibility),
      onPressed: () => setState(() => _hide = !_hide));

  Future<void> _submit() async {
    if (!_form.currentState!.validate() || _busy) return;
    setState(() => _busy = true);
    final staff = _role == 1;
    final AuthResult res;
    if (!staff && _register) {
      res = await store.register(_name.text, _email.text, _phone.text, _pass.text);
    } else {
      res = await store.signIn(_email.text, _pass.text, staffPortal: staff);
    }
    if (!mounted) return;
    setState(() => _busy = false);

    if (res.error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res.error!)));
      return;
    }
    if (res.notice != null) {
      // Account created but the email must be confirmed first: back to the login form.
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res.notice!)));
      setState(() => _register = false);
      return;
    }
    if (widget.returnOnSuccess && !staff) {
      Navigator.pop(context, true);
      return;
    }
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => staff ? const StaffShell() : const CustomerShell()),
        (r) => false);
  }

  Future<void> _forgotPassword() async {
    final done = await Navigator.push<bool>(
        context, MaterialPageRoute(builder: (_) => ForgotPasswordScreen(email: _email.text.trim())));
    if (done == true && mounted) {
      _pass.clear();
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Your password was updated. Log in with your new password.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final staff = _role == 1;
    return Scaffold(
      appBar: AppBar(title: Text(staff ? 'Staff Login' : (_register ? 'Create Account' : 'Portal Login'))),
      body: SafeArea(
        child: Form(
          key: _form,
          child: ListView(padding: const EdgeInsets.all(20), children: [
            SegmentedButton<int>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: 0, icon: Icon(Icons.person), label: Text('Customer')),
                ButtonSegment(value: 1, icon: Icon(Icons.badge), label: Text('Staff')),
              ],
              selected: {_role},
              onSelectionChanged: (s) => setState(() => _role = s.first),
            ),
            const SizedBox(height: 20),
            Text(staff ? 'Start your shift' : (_register ? 'Getting Started' : 'Welcome Back'),
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(
                staff
                    ? 'Sign in with the email and password the owner gave you.'
                    : (_register
                        ? 'Create your account to start ordering the best ribs in town.'
                        : "Let's sign you in."),
                style: const TextStyle(color: kMuted)),
            const SizedBox(height: 20),
            if (!staff && _register) ...[
              _field(_name, 'Full name'),
              _field(_phone, 'Phone number (optional)', type: TextInputType.phone, validator: (_) => null),
            ],
            _field(_email, 'Email address',
                type: TextInputType.emailAddress,
                validator: (v) => (v == null || !v.contains('@')) ? 'Enter a valid email' : null),
            _field(_pass, 'Password',
                obscure: _hide,
                suffix: _eye,
                validator: (v) => (v == null || v.isEmpty)
                    ? 'Required'
                    : ((!staff && _register && v.length < 8) ? 'At least 8 characters' : null)),
            if (!staff && _register)
              _field(_confirm, 'Confirm password',
                  obscure: _hide,
                  validator: (v) => v != _pass.text ? 'Passwords do not match' : null),
            if (!staff && !_register)
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(onPressed: _busy ? null : _forgotPassword, child: const Text('Forgot password?')),
              ),
            const SizedBox(height: 6),
            WideButton(_busy ? 'Please wait...' : (staff ? 'Start shift' : (_register ? 'Register' : 'Login')),
                _busy ? null : _submit),
            if (!staff) ...[
              const SizedBox(height: 8),
              WideButton(
                'Continue as Guest',
                () => Navigator.pushAndRemoveUntil(
                    context, MaterialPageRoute(builder: (_) => const CustomerShell()), (r) => false),
                outlined: true,
              ),
            ],
            if (!staff)
              Center(
                child: TextButton(
                  onPressed: () => setState(() => _register = !_register),
                  child: Text(_register ? 'Already registered? Login' : "Don't have an account? Register"),
                ),
              ),
            const SizedBox(height: 8),
            Text(
                staff
                    ? 'Staff and manager accounts are created by the owner. They are the same logins as the web staff portal.'
                    : 'Your account works on the Nama Nameng website.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: kMuted, fontSize: 11)),
          ]),
        ),
      ),
    );
  }
}
