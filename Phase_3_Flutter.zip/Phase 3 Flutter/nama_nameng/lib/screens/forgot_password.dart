import 'dart:async';
import 'package:flutter/material.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

/// Step 1 of "Forgot password": the customer gives their email and Supabase emails a 6-digit code.
/// Pops with `true` once the password was changed (the login screen then shows a confirmation).
class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key, this.email = ''});
  final String email;
  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _form = GlobalKey<FormState>();
  late final _email = TextEditingController(text: widget.email);
  bool _busy = false;

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!_form.currentState!.validate() || _busy) return;
    setState(() => _busy = true);
    final res = await store.requestPasswordReset(_email.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res.error!)));
      return;
    }
    final done = await Navigator.push<bool>(
        context,
        MaterialPageRoute(
            builder: (_) => ResetPasswordScreen(email: _email.text.trim().toLowerCase())));
    if (done == true && mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Forgot Password')),
        body: SafeArea(
          child: Form(
            key: _form,
            child: ListView(padding: const EdgeInsets.all(20), children: [
              const Center(child: NNLogo(size: 64)),
              const SizedBox(height: 20),
              const Text('Reset your password',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              const Text(
                  'Enter the email you registered with. We will email you a 6-digit code to choose a new password.',
                  style: TextStyle(color: kMuted)),
              const SizedBox(height: 20),
              TextFormField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                autofillHints: const [AutofillHints.email],
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _send(),
                decoration: const InputDecoration(labelText: 'Email address'),
                validator: (v) {
                  final t = (v ?? '').trim();
                  return RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(t) ? null : 'Enter a valid email';
                },
              ),
              const SizedBox(height: 18),
              WideButton(_busy ? 'Sending...' : 'Send me a code', _busy ? null : _send),
              const SizedBox(height: 8),
              Center(
                  child: TextButton(
                      onPressed: () => Navigator.pop(context), child: const Text('Back to login'))),
              const SizedBox(height: 8),
              const Text(
                  'This is for customer accounts. Staff and manager passwords are reset by the owner.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: kMuted, fontSize: 11)),
            ]),
          ),
        ),
      );
}

/// Step 2: the emailed code plus the new password. Pops with `true` on success.
class ResetPasswordScreen extends StatefulWidget {
  const ResetPasswordScreen({super.key, required this.email});
  final String email;
  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  static const _cooldown = 60; // seconds before another code can be requested

  final _form = GlobalKey<FormState>();
  final _code = TextEditingController();
  final _pass = TextEditingController();
  final _confirm = TextEditingController();
  bool _hide = true;
  bool _busy = false;
  int _left = _cooldown; // a code was just sent by the previous screen
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startCooldown();
  }

  void _startCooldown() {
    _timer?.cancel();
    _left = _cooldown;
    if (mounted) setState(() {});
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      setState(() => _left = _left > 0 ? _left - 1 : 0);
      if (_left == 0) t.cancel();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _code.dispose();
    _pass.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _resend() async {
    if (_left > 0 || _busy) return;
    setState(() => _busy = true);
    final res = await store.requestPasswordReset(widget.email);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res.error!)));
      return;
    }
    _startCooldown();
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('A new code is on its way. Use the newest email.')));
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate() || _busy) return;
    setState(() => _busy = true);
    final res = await store.resetPassword(
        email: widget.email, code: _code.text, newPassword: _pass.text);
    if (!mounted) return;
    setState(() => _busy = false);
    if (res.error != null) {
      _code.clear(); // a used or wrong code cannot be reused
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res.error!)));
      return;
    }
    Navigator.pop(context, true);
  }

  Widget get _eye => IconButton(
      tooltip: _hide ? 'Show password' : 'Hide password',
      icon: Icon(_hide ? Icons.visibility_off : Icons.visibility),
      onPressed: () => setState(() => _hide = !_hide));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('New Password')),
        body: SafeArea(
          child: Form(
            key: _form,
            child: ListView(padding: const EdgeInsets.all(20), children: [
              const Text('Check your email',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(
                  'If ${widget.email} belongs to a customer account, we sent it a 6-digit code. '
                  'It can take a few minutes; check your spam folder too.',
                  style: const TextStyle(color: kMuted)),
              const SizedBox(height: 20),
              TextFormField(
                controller: _code,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                maxLength: 10,
                autofillHints: const [AutofillHints.oneTimeCode],
                style: const TextStyle(fontSize: 24, letterSpacing: 6, fontWeight: FontWeight.w700),
                decoration: const InputDecoration(labelText: 'Code from the email', counterText: ''),
                validator: (v) =>
                    (v ?? '').replaceAll(RegExp(r'\D'), '').length < 6 ? 'Enter the 6-digit code' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _pass,
                obscureText: _hide,
                autofillHints: const [AutofillHints.newPassword],
                decoration: InputDecoration(labelText: 'New password', suffixIcon: _eye),
                validator: (v) => (v == null || v.length < 8) ? 'At least 8 characters' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _confirm,
                obscureText: _hide,
                autofillHints: const [AutofillHints.newPassword],
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _submit(),
                decoration: const InputDecoration(labelText: 'Confirm new password'),
                validator: (v) => v != _pass.text ? 'Passwords do not match' : null,
              ),
              const SizedBox(height: 18),
              WideButton(_busy ? 'Please wait...' : 'Update password', _busy ? null : _submit),
              const SizedBox(height: 8),
              Center(
                child: TextButton(
                  onPressed: (_left > 0 || _busy) ? null : _resend,
                  child: Text(_left > 0 ? 'Send a new code in ${_left}s' : 'Did not get a code? Send a new one'),
                ),
              ),
              Center(
                  child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Use a different email'))),
            ]),
          ),
        ),
      );
}
