import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'auth.dart';
import 'checkout.dart';
import 'welcome.dart';

/// Customer dashboard: Home, Menu, Cart, Profile.
class CustomerShell extends StatefulWidget {
  const CustomerShell({super.key});
  @override
  State<CustomerShell> createState() => _CustomerShellState();
}

class _CustomerShellState extends State<CustomerShell> {
  int _i = 0;
  @override
  Widget build(BuildContext context) {
    final tabs = [
      HomeTab(goTo: (i) => setState(() => _i = i)),
      const MenuTab(),
      const CartTab(),
      const ProfileTab(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _i, children: tabs)),
      bottomNavigationBar: ListenableBuilder(
        listenable: store,
        builder: (context, _) => NavigationBar(
          selectedIndex: _i,
          onDestinationSelected: (i) => setState(() => _i = i),
          destinations: [
            const NavigationDestination(
                icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            const NavigationDestination(
                icon: Icon(Icons.restaurant_menu_outlined),
                selectedIcon: Icon(Icons.restaurant_menu),
                label: 'Menu'),
            NavigationDestination(
                icon: Badge(
                    isLabelVisible: store.cartCount > 0,
                    label: Text('${store.cartCount}'),
                    child: const Icon(Icons.shopping_bag_outlined)),
                selectedIcon: const Icon(Icons.shopping_bag),
                label: 'Cart'),
            const NavigationDestination(
                icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Home
class HomeTab extends StatefulWidget {
  const HomeTab({super.key, required this.goTo});
  final void Function(int) goTo;
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  String _q = '';
  String _cat = 'All';

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final items = store.menu.where((m) => m.available).toList();
        if (items.isEmpty) {
          return const Center(child: MenuStatus());
        }
        final filtering = _q.isNotEmpty || _cat != 'All';
        final results = items
            .where((m) =>
                (_cat == 'All' || m.category == _cat) &&
                m.name.toLowerCase().contains(_q.toLowerCase()))
            .toList();
        // The database has no "popular" flag, so feature the first category (the grills) and list the rest below.
        final featuredCat = store.categories.isEmpty ? '' : store.categories.first.name;
        final featured = items.where((m) => m.category == featuredCat).toList();
        final more = items.where((m) => m.category != featuredCat).toList();
        final first = store.user?.fullName.split(' ').first ?? 'Guest';
        return ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Hello,', style: TextStyle(color: kMuted)),
                Text('$first! 👋',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              ]),
            ),
            const NNLogo(size: 42),
          ]),
          const SizedBox(height: 14),
          TextField(
            onChanged: (v) => setState(() => _q = v),
            decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search), hintText: 'Search dishes, sides...'),
          ),
          const SizedBox(height: 12),
          CategoryChips(selected: _cat, onSelected: (c) => setState(() => _cat = c)),
          if (filtering) ...[
            SectionTitle('Results (${results.length})'),
            if (results.isEmpty)
              const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: Text('Nothing matches that search.', style: TextStyle(color: kMuted)))),
            ...results.map(DishTile.new),
          ] else ...[
            if (featured.isNotEmpty) ...[
              SectionTitle(featuredCat, action: 'View menu', onAction: () => widget.goTo(1)),
              SizedBox(
                height: 205,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: featured
                      .map((m) => Padding(
                          padding: const EdgeInsets.only(right: 12), child: _PopularCard(m)))
                      .toList(),
                ),
              ),
            ],
            if (more.isNotEmpty) ...[
              const SectionTitle('More on the menu'),
              ...more.map(DishTile.new),
            ],
          ],
        ]);
      },
    );
  }
}

class _PopularCard extends StatelessWidget {
  const _PopularCard(this.item);
  final MenuItem item;
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 160,
        child: NNCard(
          padding: EdgeInsets.zero,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            FoodImage(item.image, w: 160, h: 105, radius: 0),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(item.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 6),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text(money(item.price),
                      style: const TextStyle(color: kOrange, fontWeight: FontWeight.w700)),
                  InkWell(
                    onTap: () => store.addToCart(item),
                    customBorder: const CircleBorder(),
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: kOrange),
                      child: const Icon(Icons.add, size: 18, color: Colors.black),
                    ),
                  ),
                ]),
              ]),
            ),
          ]),
        ),
      );
}

// ---------------------------------------------------------------- Menu
class MenuTab extends StatefulWidget {
  const MenuTab({super.key});
  @override
  State<MenuTab> createState() => _MenuTabState();
}

class _MenuTabState extends State<MenuTab> {
  String _q = '';
  String _cat = 'All';
  bool _search = false;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final list = store.menu
              .where((m) =>
                  m.available &&
                  (_cat == 'All' || m.category == _cat) &&
                  m.name.toLowerCase().contains(_q.toLowerCase()))
              .toList();
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Expanded(
                    child: Text('Nama Nameng Menu',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
                IconButton(
                    icon: Icon(_search ? Icons.close : Icons.search),
                    onPressed: () => setState(() {
                          _search = !_search;
                          if (!_search) _q = '';
                        })),
              ]),
              if (_search) ...[
                const SizedBox(height: 10),
                TextField(
                    autofocus: true,
                    onChanged: (v) => setState(() => _q = v),
                    decoration: const InputDecoration(hintText: 'Search the menu')),
              ],
              const SizedBox(height: 10),
              CategoryChips(selected: _cat, onSelected: (c) => setState(() => _cat = c)),
              const SizedBox(height: 10),
              Expanded(
                child: store.menu.isEmpty
                    ? const Center(child: MenuStatus())
                    : RefreshIndicator(
                        onRefresh: store.refreshMenu,
                        child: list.isEmpty
                            ? ListView(children: const [
                                Padding(
                                    padding: EdgeInsets.all(32),
                                    child: Center(
                                        child: Text('No dishes found.', style: TextStyle(color: kMuted))))
                              ])
                            : ListView(children: list.map(DishTile.new).toList()),
                      ),
              ),
            ]),
          );
        },
      );
}

// ---------------------------------------------------------------- Cart
class CartTab extends StatelessWidget {
  const CartTab({super.key});

  // Guests can order without an account (same as the website); checkout asks for a name.
  void _proceed(BuildContext context) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => const CheckoutScreen()));

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          if (store.cart.isEmpty) {
            return const Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.shopping_bag_outlined, size: 56, color: kMuted),
                SizedBox(height: 10),
                Text('Your basket is empty', style: TextStyle(fontWeight: FontWeight.w700)),
                Text('Add something tasty from the menu.', style: TextStyle(color: kMuted)),
              ]),
            );
          }
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              const Text('Checkout Summary',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              Expanded(
                child: ListView(children: [
                  for (final l in store.cart)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: NNCard(
                        padding: const EdgeInsets.all(10),
                        child: Row(children: [
                          FoodImage(l.item.image, w: 54, h: 54),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(l.item.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                              Text(money(l.total), style: const TextStyle(color: kOrange)),
                            ]),
                          ),
                          QtyStepper(l.qty, () => store.removeOne(l.item), () => store.addToCart(l.item)),
                          IconButton(
                              icon: const Icon(Icons.delete_outline, color: kMuted),
                              onPressed: () => store.removeLine(l.item)),
                        ]),
                      ),
                    ),
                ]),
              ),
              TotalsBlock(total: store.total),
              const SizedBox(height: 10),
              WideButton('Proceed to Checkout', () => _proceed(context)),
            ]),
          );
        },
      );
}

// ---------------------------------------------------------------- Profile
class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});
  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  String? _loadedFor;

  void _sync() {
    final u = store.user;
    if (_loadedFor != u?.id) {
      _loadedFor = u?.id;
      _name.text = u?.fullName ?? '';
      _phone.text = u?.phone ?? '';
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Widget _orderCard(BuildContext context, Order o) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: NNCard(
          onTap: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => TrackOrderScreen(orderId: o.id))),
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('#${o.number}', style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(o.summary,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: kMuted, fontSize: 12)),
              ]),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(money(o.total), style: const TextStyle(color: kOrange, fontWeight: FontWeight.w700)),
              StatusChip(o.status),
            ]),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          _sync();
          final u = store.user;
          final mine = store.myOrders;
          if (u == null) {
            // Not registered: either nobody is signed in, or this is a guest session that has placed orders.
            return ListView(padding: const EdgeInsets.all(24), children: [
              const SizedBox(height: 16),
              const Center(child: NNLogo(size: 70)),
              const SizedBox(height: 16),
              const Text('Sign in to see your profile and order history',
                  textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              WideButton('Sign in', () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const AuthScreen()))),
              if (mine.isNotEmpty) ...[
                SectionTitle('Orders from this session (${mine.length})'),
                for (final o in mine) _orderCard(context, o),
              ],
            ]);
          }
          return ListView(padding: const EdgeInsets.all(16), children: [
            const Center(child: Text('My Profile', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
            const SizedBox(height: 16),
            Center(
              child: CircleAvatar(
                radius: 38,
                backgroundColor: kOrange,
                child: Text(u.fullName.isEmpty ? '?' : u.fullName[0].toUpperCase(),
                    style: const TextStyle(fontSize: 30, color: Colors.black, fontWeight: FontWeight.w800)),
              ),
            ),
            const SizedBox(height: 8),
            Center(child: Text(u.fullName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
            const SizedBox(height: 16),
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'Full name')),
            const SizedBox(height: 10),
            TextFormField(
                key: ValueKey(u.email),
                initialValue: u.email,
                readOnly: true,
                decoration: const InputDecoration(labelText: 'Email address')),
            const SizedBox(height: 10),
            TextField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone number')),
            const SizedBox(height: 14),
            WideButton('Update Profile', () async {
              if (_name.text.trim().isEmpty) return;
              final err = await store.updateProfile(_name.text, _phone.text);
              if (!context.mounted) return;
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(err ?? 'Profile updated')));
            }),
            SectionTitle('My orders (${mine.length})'),
            if (mine.isEmpty)
              const Text('No orders yet.', style: TextStyle(color: kMuted)),
            for (final o in mine) _orderCard(context, o),
            const SizedBox(height: 10),
            WideButton('Log out', () async {
              await store.signOut();
              if (!context.mounted) return;
              Navigator.pushAndRemoveUntil(
                  context, MaterialPageRoute(builder: (_) => const WelcomeScreen()), (r) => false);
            }, outlined: true, danger: true),
          ]);
        },
      );
}
