import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'welcome.dart';

void _snack(BuildContext context, String msg) =>
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

/// Moves an order to a new status through the database function (staff only), or explains why it can't.
Future<bool> _act(BuildContext context, int id, OrderStatus s) async {
  final ok = await store.updateOrder(id, s);
  if (!ok && context.mounted) {
    _snack(context, store.lastActionError ?? 'Could not update the order.');
  }
  return ok;
}

void _openOrder(BuildContext context, int id) => Navigator.push(
    context, MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: id)));

/// Staff dashboard: Home, Orders, Kitchen, Menu, Profile.
class StaffShell extends StatefulWidget {
  const StaffShell({super.key});
  @override
  State<StaffShell> createState() => _StaffShellState();
}

class _StaffShellState extends State<StaffShell> {
  int _i = 0;
  @override
  Widget build(BuildContext context) {
    final tabs = [
      StaffHome(goTo: (i) => setState(() => _i = i)),
      const StaffOrders(),
      const StaffKitchen(),
      const StaffMenu(),
      const StaffProfile(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _i, children: tabs)),
      bottomNavigationBar: ListenableBuilder(
        listenable: store,
        builder: (context, _) => NavigationBar(
          selectedIndex: _i,
          onDestinationSelected: (i) => setState(() => _i = i),
          destinations: [
            const NavigationDestination(
                icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
            NavigationDestination(
                icon: Badge(
                    isLabelVisible: store.waitingCount > 0,
                    label: Text('${store.waitingCount}'),
                    child: const Icon(Icons.receipt_long_outlined)),
                selectedIcon: const Icon(Icons.receipt_long),
                label: 'Orders'),
            const NavigationDestination(
                icon: Icon(Icons.soup_kitchen_outlined), selectedIcon: Icon(Icons.soup_kitchen), label: 'Kitchen'),
            const NavigationDestination(
                icon: Icon(Icons.restaurant_menu_outlined), selectedIcon: Icon(Icons.restaurant_menu), label: 'Menu'),
            const NavigationDestination(
                icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Home
class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value, {this.color});
  final String label;
  final String value;
  final Color? color;
  @override
  Widget build(BuildContext context) => NNCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: kMuted, fontSize: 10, letterSpacing: 1)),
          const SizedBox(height: 4),
          Text(value,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color ?? Colors.white)),
        ]),
      );
}

class _Alert extends StatelessWidget {
  const _Alert(this.color, this.text, this.onTap);
  final Color color;
  final String text;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: NNCard(
          onTap: onTap,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(children: [
            Icon(Icons.circle, size: 10, color: color),
            const SizedBox(width: 10),
            Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
            const Icon(Icons.chevron_right, color: kMuted, size: 18),
          ]),
        ),
      );
}

class StaffHome extends StatelessWidget {
  const StaffHome({super.key, required this.goTo});
  final void Function(int) goTo;

  String get _greet {
    final h = DateTime.now().hour;
    return h < 12 ? 'Good morning' : (h < 17 ? 'Good afternoon' : 'Good evening');
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final name = (store.staff?.fullName ?? 'Team').split(' ').first;
          final noAlerts = store.waitingCount == 0 && store.readyCount == 0 && store.soldOutCount == 0;
          final top = store.topItems;
          return RefreshIndicator(
            onRefresh: () async {
              await store.refreshOrders();
              await store.refreshMenu();
            },
            child: ListView(padding: const EdgeInsets.all(16), children: [
              StaffHeader(
                  kicker: '${(store.staff?.role ?? 'Staff').toUpperCase()} • NAMA NAMENG',
                  title: '$_greet, $name'),
              Row(children: [
                Expanded(child: _Stat('ACTIVE ORDERS', '${store.activeCount}')),
                const SizedBox(width: 10),
                Expanded(
                  child: Tick(
                    builder: (_) => _Stat(
                        'ON SHIFT (MM:SS)',
                        mmss(DateTime.now().difference(store.shiftStart ?? DateTime.now())),
                        color: store.onBreak ? kYellow : kGreen),
                  ),
                ),
              ]),
              const SectionTitle('Live alerts'),
              if (store.waitingCount > 0)
                _Alert(kYellow, '${store.waitingCount} new order(s) waiting', () => goTo(1)),
              if (store.readyCount > 0)
                _Alert(kGreen, '${store.readyCount} order(s) ready for pickup', () => goTo(2)),
              if (store.soldOutCount > 0)
                _Alert(kRed, '${store.soldOutCount} menu item(s) marked sold out', () => goTo(3)),
              if (noAlerts) const Text('All clear — nothing needs attention.', style: TextStyle(color: kMuted)),
              const SectionTitle('Today so far'),
              Row(children: [
                Expanded(child: _Stat('ORDERS', '${store.todaysOrders.length}')),
                const SizedBox(width: 10),
                Expanded(child: _Stat('SALES', money(store.salesToday))),
                const SizedBox(width: 10),
                Expanded(child: _Stat('CANCELLED', '${store.cancelledToday}', color: kRed)),
              ]),
              if (store.isManager) ...[
                const SectionTitle('Top sellers (recent orders)'),
                if (top.isEmpty) const Text('No orders yet.', style: TextStyle(color: kMuted)),
                for (final t in top)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text(t.key),
                      Text('${t.value} sold', style: const TextStyle(color: kOrange, fontWeight: FontWeight.w700)),
                    ]),
                  ),
              ],
            ]),
          );
        },
      );
}

// ---------------------------------------------------------------- Incoming orders
class StaffOrders extends StatelessWidget {
  const StaffOrders({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final list = store.ordersWith(OrderStatus.received);
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              StaffHeader(kicker: 'ORDERS • ${list.length} WAITING', title: 'Incoming orders'),
              if (store.onBreak)
                const Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Text('On break — order actions are paused.', style: TextStyle(color: kYellow)),
                ),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: store.refreshOrders,
                  child: list.isEmpty
                      ? ListView(children: const [
                          Padding(
                              padding: EdgeInsets.all(40),
                              child: Center(
                                  child: Text('No new orders right now.', style: TextStyle(color: kMuted))))
                        ])
                      : ListView(children: [
                          for (final o in list)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: NNCard(
                                onTap: () => _openOrder(context, o.id),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(children: [
                                    Text('#${o.number}', style: const TextStyle(fontWeight: FontWeight.w800)),
                                    const Spacer(),
                                    Text(ago(o.placedAt), style: const TextStyle(color: kMuted, fontSize: 12)),
                                  ]),
                                  const SizedBox(height: 4),
                                  Text(o.customerName, style: const TextStyle(color: kMuted, fontSize: 12)),
                                  const SizedBox(height: 6),
                                  Text(o.summary),
                                  const SizedBox(height: 6),
                                  Text(money(o.total),
                                      style: const TextStyle(color: kOrange, fontWeight: FontWeight.w800)),
                                  const SizedBox(height: 10),
                                  Row(children: [
                                    Expanded(
                                      child: OutlinedButton(
                                        style: OutlinedButton.styleFrom(
                                            foregroundColor: kRed, side: const BorderSide(color: kRed)),
                                        onPressed: () => _act(context, o.id, OrderStatus.cancelled),
                                        child: const Text('Cancel'),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: FilledButton(
                                        onPressed: () => _act(context, o.id, OrderStatus.preparing),
                                        child: const Text('Start preparing'),
                                      ),
                                    ),
                                  ]),
                                ]),
                              ),
                            ),
                        ]),
                ),
              ),
            ]),
          );
        },
      );
}

// ---------------------------------------------------------------- Order detail
class OrderDetailScreen extends StatelessWidget {
  const OrderDetailScreen({super.key, required this.orderId});
  final int orderId;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final o = store.orderById(orderId);
          if (o == null) {
            return Scaffold(
                appBar: AppBar(title: const Text('Order')),
                body: const Center(child: CircularProgressIndicator()));
          }
          final open = o.status.isOpen;
          return Scaffold(
            appBar: AppBar(title: Text('Order #${o.number}')),
            body: SafeArea(
              child: ListView(padding: const EdgeInsets.all(16), children: [
                if (open)
                  Tick(builder: (_) {
                    final d = DateTime.now().difference(o.placedAt);
                    final isLate = d.inMinutes >= kTargetMinutes;
                    return NNCard(
                      borderColor: isLate ? kRed : kBorder,
                      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('ELAPSED', style: TextStyle(color: kMuted, fontSize: 10, letterSpacing: 1)),
                          Text(mmss(d),
                              style: TextStyle(
                                  fontSize: 30, fontWeight: FontWeight.w800, color: isLate ? kRed : Colors.white)),
                          Text('Target: $kTargetMinutes min',
                              style: const TextStyle(color: kMuted, fontSize: 12)),
                        ]),
                        StatusChip(o.status),
                      ]),
                    );
                  })
                else
                  Align(alignment: Alignment.centerLeft, child: StatusChip(o.status)),
                const SectionTitle('Item breakdown'),
                NNCard(
                  child: Column(children: [
                    for (final l in o.lines)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text('${l.qty}x ${l.name}'),
                          Text(money(l.total)),
                        ]),
                      ),
                    const Divider(color: kBorder),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('Total', style: TextStyle(fontWeight: FontWeight.w800)),
                      Text(money(o.total),
                          style: const TextStyle(color: kOrange, fontWeight: FontWeight.w800, fontSize: 18)),
                    ]),
                  ]),
                ),
                const SectionTitle('Order info'),
                NNCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Customer: ${o.customerName}'),
                    const SizedBox(height: 4),
                    const Text('Self pickup • pay at the counter (cash or card)'),
                    if (o.note.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text('Customer note: ${o.note}', style: const TextStyle(color: kYellow)),
                    ],
                  ]),
                ),
                const SizedBox(height: 16),
                if (o.status == OrderStatus.received)
                  WideButton('Start preparing', () => _act(context, o.id, OrderStatus.preparing))
                else if (o.status == OrderStatus.preparing || o.status == OrderStatus.ready) ...[
                  const Text('PREPARATION STATUS',
                      style: TextStyle(color: kMuted, fontSize: 10, letterSpacing: 1)),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: SegmentedButton<OrderStatus>(
                      showSelectedIcon: false,
                      segments: const [
                        ButtonSegment(value: OrderStatus.preparing, label: Text('Preparing')),
                        ButtonSegment(value: OrderStatus.ready, label: Text('Ready')),
                      ],
                      selected: {o.status},
                      onSelectionChanged: (s) => _act(context, o.id, s.first),
                    ),
                  ),
                  if (o.status == OrderStatus.ready) ...[
                    const SizedBox(height: 12),
                    WideButton('Mark as collected', () => _act(context, o.id, OrderStatus.collected)),
                  ],
                ],
                if (open) ...[
                  const SizedBox(height: 10),
                  WideButton('Cancel order', () async {
                    final ok = await _act(context, o.id, OrderStatus.cancelled);
                    if (ok && context.mounted) Navigator.pop(context);
                  }, outlined: true, danger: true),
                ],
              ]),
            ),
          );
        },
      );
}

// ---------------------------------------------------------------- Kitchen queue
class StaffKitchen extends StatelessWidget {
  const StaffKitchen({super.key});

  Widget _section(BuildContext context, String title, List<Order> list, String label, OrderStatus next) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SectionTitle('$title (${list.length})'),
      if (list.isEmpty) const Text('Nothing here.', style: TextStyle(color: kMuted, fontSize: 12)),
      for (final o in list)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: NNCard(
            onTap: () => _openOrder(context, o.id),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('#${o.number} • ${o.customerName}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(o.summary,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: kMuted, fontSize: 12)),
                  Text(ago(o.placedAt), style: const TextStyle(color: kMuted, fontSize: 11)),
                ]),
              ),
              const SizedBox(width: 8),
              FilledButton(
                  style: smallBtn, onPressed: () => _act(context, o.id, next), child: Text(label)),
            ]),
          ),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) => RefreshIndicator(
          onRefresh: store.refreshOrders,
          child: ListView(padding: const EdgeInsets.all(16), children: [
            const StaffHeader(kicker: 'KITCHEN', title: 'Kitchen queue'),
            if (store.onBreak)
              const Text('On break — order actions are paused.', style: TextStyle(color: kYellow)),
            _section(context, 'Preparing', store.ordersWith(OrderStatus.preparing), 'Ready', OrderStatus.ready),
            _section(context, 'Ready for pickup', store.ordersWith(OrderStatus.ready), 'Collected',
                OrderStatus.collected),
          ]),
        ),
      );
}

// ---------------------------------------------------------------- Menu
/// Everyone on staff can see the menu; only managers can change it (the database enforces this too).
class StaffMenu extends StatefulWidget {
  const StaffMenu({super.key});
  @override
  State<StaffMenu> createState() => _StaffMenuState();
}

class _StaffMenuState extends State<StaffMenu> {
  String _cat = 'All';

  Future<void> _addCategory() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New category'),
        content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(labelText: 'Name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Add')),
        ],
      ),
    );
    c.dispose();
    if (name == null || !mounted) return;
    final err = await store.addCategory(name);
    if (mounted) _snack(context, err ?? 'Category added.');
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final manager = store.isManager;
          final list = store.menu.where((m) => _cat == 'All' || m.category == _cat).toList();
          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              StaffHeader(
                kicker: 'MENU • ${store.menu.length} ITEMS',
                title: manager ? 'Menu management' : 'Menu',
                trailing: manager
                    ? Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(
                            tooltip: 'New category',
                            icon: const Icon(Icons.create_new_folder_outlined),
                            onPressed: _addCategory),
                        FilledButton.icon(
                          style: smallBtn,
                          icon: const Icon(Icons.add, size: 18),
                          label: const Text('Add'),
                          onPressed: store.categories.isEmpty
                              ? null
                              : () => Navigator.push(
                                  context, MaterialPageRoute(builder: (_) => const EditItemScreen())),
                        ),
                      ])
                    : null,
              ),
              if (!manager)
                const Padding(
                  padding: EdgeInsets.only(bottom: 8),
                  child: Text('Only managers can change the menu.', style: TextStyle(color: kMuted, fontSize: 12)),
                ),
              CategoryChips(selected: _cat, onSelected: (c) => setState(() => _cat = c)),
              const SizedBox(height: 10),
              Expanded(
                child: store.menu.isEmpty
                    ? const Center(child: MenuStatus())
                    : RefreshIndicator(
                        onRefresh: store.refreshMenu,
                        child: ListView(children: [
                          for (final m in list)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: NNCard(
                                padding: const EdgeInsets.all(10),
                                onTap: manager
                                    ? () => Navigator.push(context,
                                        MaterialPageRoute(builder: (_) => EditItemScreen(item: m)))
                                    : null,
                                child: Row(children: [
                                  FoodImage(m.image, w: 56, h: 56),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                      Text(m.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                                      Text('${money(m.price)} • ${m.category}',
                                          style: const TextStyle(color: kMuted, fontSize: 11)),
                                      if (!m.available)
                                        const Text('SOLD OUT',
                                            style: TextStyle(color: kRed, fontSize: 10, fontWeight: FontWeight.w800)),
                                    ]),
                                  ),
                                  if (manager)
                                    Switch(
                                        value: m.available,
                                        onChanged: (v) async {
                                          final err = await store.toggleAvailable(m, v);
                                          if (err != null && context.mounted) _snack(context, err);
                                        }),
                                ]),
                              ),
                            ),
                        ]),
                      ),
              ),
            ]),
          );
        },
      );
}

// ---------------------------------------------------------------- Add / edit item (manager)
class EditItemScreen extends StatefulWidget {
  const EditItemScreen({super.key, this.item});
  final MenuItem? item;
  @override
  State<EditItemScreen> createState() => _EditItemScreenState();
}

class _EditItemScreenState extends State<EditItemScreen> {
  final _form = GlobalKey<FormState>();
  bool _busy = false;
  late final _name = TextEditingController(text: widget.item?.name ?? '');
  late final _price = TextEditingController(text: widget.item?.price.toStringAsFixed(2) ?? '');
  late final _desc = TextEditingController(text: widget.item?.description ?? '');
  late final _image = TextEditingController(text: widget.item?.imageUrl ?? '');
  late int _catId = widget.item?.categoryId ?? store.categories.first.id;
  late bool _available = widget.item?.available ?? true;

  @override
  void dispose() {
    for (final c in [_name, _price, _desc, _image]) {
      c.dispose();
    }
    super.dispose();
  }

  String get _catName => store.categories.firstWhere((c) => c.id == _catId).name;

  Future<void> _save({bool soldOut = false}) async {
    if (!_form.currentState!.validate() || _busy) return;
    setState(() => _busy = true);
    final err = await store.saveItem(
      id: widget.item?.id,
      categoryId: _catId,
      name: _name.text,
      description: _desc.text,
      price: double.parse(_price.text.trim().replaceAll(',', '.')),
      imageUrl: _image.text,
      available: soldOut ? false : _available,
    );
    if (!mounted) return;
    if (err != null) {
      setState(() => _busy = false);
      _snack(context, err);
      return;
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.item != null;
    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'Edit menu item' : 'New menu item')),
      body: SafeArea(
        child: Form(
          key: _form,
          child: ListView(padding: const EdgeInsets.all(16), children: [
            FoodImage(
                _image.text.trim().startsWith('http') ? _image.text.trim() : imageFor(_catName, _name.text),
                w: double.infinity,
                h: 160,
                radius: 14),
            const SizedBox(height: 14),
            TextFormField(
                controller: _name,
                maxLength: 60,
                decoration: const InputDecoration(labelText: 'Item name'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter an item name' : null),
            const SizedBox(height: 4),
            TextFormField(
              controller: _price,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Price (R)'),
              validator: (v) {
                final n = double.tryParse((v ?? '').trim().replaceAll(',', '.'));
                return (n == null || n <= 0 || n > 5000) ? 'Enter a price between R0.01 and R5000' : null;
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
                controller: _desc,
                maxLines: 3,
                maxLength: 200,
                decoration: const InputDecoration(labelText: 'Description')),
            const SizedBox(height: 4),
            TextFormField(
              controller: _image,
              keyboardType: TextInputType.url,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(labelText: 'Picture address (optional, https://...)'),
              validator: (v) {
                final t = (v ?? '').trim();
                if (t.isEmpty) return null;
                final u = Uri.tryParse(t);
                return (u != null && u.isAbsolute && (u.scheme == 'http' || u.scheme == 'https'))
                    ? null
                    : 'Use a full web address starting with http:// or https://';
              },
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _catId,
              decoration: const InputDecoration(labelText: 'Category'),
              items: store.categories.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
              onChanged: (v) => setState(() => _catId = v!),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Available to order'),
              value: _available,
              onChanged: (v) => setState(() => _available = v),
            ),
            const SizedBox(height: 8),
            WideButton(_busy ? 'Saving...' : 'Save changes', _busy ? null : _save),
            const SizedBox(height: 10),
            WideButton('Save as sold out', _busy ? null : () => _save(soldOut: true), outlined: true),
            if (editing) ...[
              const SizedBox(height: 10),
              WideButton('Delete item', () async {
                final msg = await store.deleteItem(widget.item!);
                if (!context.mounted) return;
                _snack(context, msg);
                Navigator.pop(context);
              }, outlined: true, danger: true),
            ],
          ]),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Staff profile
class StaffProfile extends StatelessWidget {
  const StaffProfile({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final s = store.staff;
          final started = store.shiftStart;
          return ListView(padding: const EdgeInsets.all(16), children: [
            const StaffHeader(kicker: 'FRONT OF HOUSE', title: 'Staff profile'),
            NNCard(
              child: Row(children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: kOrange,
                  child: Text(((s?.fullName ?? '').isEmpty ? 'N' : s!.fullName[0]).toUpperCase(),
                      style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w800, fontSize: 20)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(s?.fullName ?? 'Staff', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    Text('${s?.role ?? ''} • ${s?.email ?? ''}',
                        style: const TextStyle(color: kMuted, fontSize: 12)),
                  ]),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                      color: (store.onBreak ? kYellow : kGreen).withAlpha(40),
                      borderRadius: BorderRadius.circular(6)),
                  child: Text(store.onBreak ? 'ON BREAK' : 'ON SHIFT',
                      style: TextStyle(
                          color: store.onBreak ? kYellow : kGreen, fontSize: 10, fontWeight: FontWeight.w800)),
                ),
              ]),
            ),
            const SectionTitle('Current shift'),
            Row(children: [
              Expanded(child: _Stat('ORDERS TODAY', '${store.todaysOrders.length}')),
              const SizedBox(width: 10),
              Expanded(
                  child: _Stat('COLLECTED',
                      '${store.todaysOrders.where((o) => o.status == OrderStatus.collected).length}')),
            ]),
            const SizedBox(height: 10),
            NNCard(
              child: Column(children: [
                _line('Shift started',
                    started == null ? '—' : '${started.hour.toString().padLeft(2, '0')}:${started.minute.toString().padLeft(2, '0')}'),
                _line('Sales today', money(store.salesToday)),
              ]),
            ),
            const SectionTitle('Quick actions'),
            WideButton(store.onBreak ? 'Resume shift' : 'Take break', store.toggleBreak, outlined: true),
            const SizedBox(height: 10),
            WideButton('End shift', () async {
              await store.signOut();
              if (!context.mounted) return;
              Navigator.pushAndRemoveUntil(
                  context, MaterialPageRoute(builder: (_) => const WelcomeScreen()), (r) => false);
            }, danger: true),
          ]);
        },
      );

  Widget _line(String l, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(l, style: const TextStyle(color: kMuted)),
          Text(v, style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
      );
}
