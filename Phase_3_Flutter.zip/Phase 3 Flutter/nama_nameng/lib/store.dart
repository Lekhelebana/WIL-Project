import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'models.dart';

/// One shared store for the customer and staff dashboards.
///
/// All data lives in the same Supabase project as the ASP.NET web app:
///   * logins      -> Supabase Auth (email + password; guests order without signing in)
///   * menu        -> menu_categories / menu_items (read by everyone, written by managers)
///   * orders      -> orders / order_items, created ONLY through place_order() / place_guest_order()
///   * status      -> set_order_status() function (staff only)
/// Row Level Security decides what each signed-in user may see or change.
final store = AppStore();

/// Result of a sign-in / register call: [error] is a message for the user, [notice] a friendly info text.
class AuthResult {
  const AuthResult({this.error, this.notice});
  final String? error;
  final String? notice;
  bool get ok => error == null;
}

class AppStore extends ChangeNotifier {
  // Created lazily so unit tests can use the cart without initialising Supabase.
  SupabaseClient get _db => Supabase.instance.client;

  // ---------- session ----------
  Profile? profile; // null when nobody is signed in (not even a guest session)
  bool onBreak = false; // local to this device (staff only)
  DateTime? shiftStart;

  /// A registered customer (not a guest session).
  Profile? get user => (profile != null && !profile!.isAnonymous && !profile!.isStaff) ? profile : null;
  Profile? get staff => (profile != null && profile!.isStaff) ? profile : null;
  bool get isStaff => staff != null;
  bool get isManager => profile?.isManager ?? false;

  /// Random id that identifies a guest on this device (never leaves the app except to Supabase).
  /// Guests do NOT need a Supabase login: orders are created with place_guest_order() and read back
  /// with get_guest_orders(), both keyed by this id.
  String? _guestId;
  String get guestId => _guestId ??= _newGuestId();
  static String _newGuestId() {
    final r = Random.secure();
    return List.generate(32, (_) => r.nextInt(16).toRadixString(16)).join();
  }

  Timer? _ordersTimer;
  Timer? _menuTimer;
  RealtimeChannel? _channel;
  bool _started = false;

  /// Call once after Supabase.initialize().
  Future<void> init() async {
    if (_started) return;
    _started = true;
    await _loadProfile();
    unawaited(refreshMenu());
    unawaited(refreshOrders());
    _ordersTimer = Timer.periodic(const Duration(seconds: 5), (_) => refreshOrders());
    _menuTimer = Timer.periodic(const Duration(seconds: 30), (_) => refreshMenu());
    try {
      // Live updates; the 5 s timer above is the fallback if Realtime is unavailable.
      _channel = _db
          .channel('public:orders')
          .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: 'orders',
              callback: (_) => refreshOrders())
          .subscribe();
    } catch (_) {}
  }

  @override
  void dispose() {
    _ordersTimer?.cancel();
    _menuTimer?.cancel();
    _channel?.unsubscribe();
    super.dispose();
  }

  Future<void> _loadProfile() async {
    final u = _db.auth.currentUser;
    if (u == null) {
      profile = null;
      return;
    }
    try {
      final row = await _db.from('profiles').select().eq('id', u.id).maybeSingle();
      profile = row == null ? null : Profile.fromJson(row, isAnonymous: u.isAnonymous);
    } catch (_) {
      // keep whatever we had; the next refresh will try again
    }
  }

  // ---------- auth ----------
  /// [staffPortal] mirrors the two web logins: /Account/Login (customers) and /Portal/Login (staff, managers).
  Future<AuthResult> signIn(String email, String password, {required bool staffPortal}) async {
    try {
      await _db.auth.signInWithPassword(email: email.trim().toLowerCase(), password: password);
      await _loadProfile();
      final p = profile;
      if (p == null || !p.isActive) {
        await _db.auth.signOut();
        profile = null;
        notifyListeners();
        return const AuthResult(error: 'Incorrect email or password.');
      }
      if (staffPortal && !p.isStaff) {
        await _db.auth.signOut();
        profile = null;
        notifyListeners();
        return const AuthResult(
            error: 'This is for staff and managers. Customers can log in on the Customer tab.');
      }
      if (!staffPortal && p.isStaff) {
        await _db.auth.signOut();
        profile = null;
        notifyListeners();
        return const AuthResult(error: 'This is a staff account. Please use the Staff tab.');
      }
      if (p.isStaff) {
        shiftStart = DateTime.now();
        onBreak = false;
      }
      await refreshOrders();
      notifyListeners();
      return const AuthResult();
    } catch (e) {
      return AuthResult(error: friendlyError(e));
    }
  }

  Future<AuthResult> register(String name, String email, String phone, String password) async {
    try {
      final res = await _db.auth.signUp(
        email: email.trim().toLowerCase(),
        password: password,
        data: {'full_name': name.trim(), if (phone.trim().isNotEmpty) 'phone': phone.trim()},
      );
      if (res.session == null) {
        // "Confirm email" is ON in Supabase: no session until the link is clicked.
        return const AuthResult(
            notice: 'Account created. Check your email and click the confirmation link, then log in.');
      }
      await _loadProfile();
      await refreshOrders();
      notifyListeners();
      return const AuthResult();
    } catch (e) {
      return AuthResult(error: friendlyError(e));
    }
  }

  // ---------- forgot / reset password (customers) ----------
  // Step 1: Supabase emails a one-time code. Step 2: the customer types the code and a new password.
  // Same flow as the web app (/Account/ForgotPassword). Staff and manager passwords are reset by the owner.

  /// Sends the reset code. Supabase answers the same way for unknown emails, so nothing is revealed.
  Future<AuthResult> requestPasswordReset(String email) async {
    try {
      await _db.auth.resetPasswordForEmail(email.trim().toLowerCase());
      return const AuthResult();
    } catch (e) {
      return AuthResult(error: friendlyError(e));
    }
  }

  /// Checks the emailed code, then sets the new password. The recovery session is always closed afterwards,
  /// so the customer logs in again with the new password.
  Future<AuthResult> resetPassword({
    required String email,
    required String code,
    required String newPassword,
  }) async {
    var verified = false;
    try {
      final res = await _db.auth.verifyOTP(
        email: email.trim().toLowerCase(),
        token: code.replaceAll(RegExp(r'\D'), ''),
        type: OtpType.recovery,
      );
      verified = res.session != null;
      if (!verified) {
        return const AuthResult(error: 'That code is incorrect or has expired. Request a new one.');
      }
      // Only customers can reset here. Staff and managers ask the owner.
      final row = await _db.from('profiles').select().eq('id', res.session!.user.id).maybeSingle();
      final p = row == null ? null : Profile.fromJson(row);
      if (p == null || !p.isActive || p.role != Roles.customer) {
        return const AuthResult(
            error: 'This account cannot be reset here. Staff and manager passwords are reset by the owner.');
      }
      await _db.auth.updateUser(UserAttributes(password: newPassword));
      return const AuthResult();
    } on AuthException catch (e) {
      final low = e.message.toLowerCase();
      final String msg;
      if (e.code == 'otp_expired' || (!verified && (low.contains('expired') || low.contains('invalid')))) {
        msg = 'That code is incorrect or has expired. Request a new one.';
      } else if (e.code == 'same_password' || low.contains('different from the old')) {
        msg = 'Choose a password you have not used before. The code you entered has been used, so request a new one.';
      } else {
        msg = '${friendlyError(e)}${verified ? ' The code you entered has been used, so request a new one.' : ''}';
      }
      return AuthResult(error: msg);
    } catch (e) {
      return AuthResult(error: friendlyError(e));
    } finally {
      if (verified) {
        try {
          await _db.auth.signOut();
        } catch (_) {}
        profile = null;
        orders = [];
        notifyListeners();
      }
    }
  }

  Future<void> signOut() async {
    try {
      await _db.auth.signOut();
    } catch (_) {}
    profile = null;
    orders = [];
    _guestId = null;
    cart.clear();
    shiftStart = null;
    onBreak = false;
    notifyListeners();
  }

  /// Returns an error message, or null on success.
  Future<String?> updateProfile(String name, String phone) async {
    final p = profile;
    if (p == null) return 'Please sign in first.';
    try {
      await _db
          .from('profiles')
          .update({'full_name': name.trim(), 'phone': phone.trim().isEmpty ? null : phone.trim()})
          .eq('id', p.id);
      p.fullName = name.trim();
      p.phone = phone.trim();
      notifyListeners();
      return null;
    } catch (e) {
      return friendlyError(e);
    }
  }

  void toggleBreak() {
    onBreak = !onBreak;
    notifyListeners();
  }

  // ---------- menu ----------
  List<MenuCategory> categories = [];
  List<MenuItem> menu = [];
  bool menuLoading = true;
  String? menuError;

  List<String> get categoryNames => categories.map((c) => c.name).toList();

  Future<void> refreshMenu() async {
    try {
      final cats = await _db.from('menu_categories').select().order('sort_order').order('name');
      final items = await _db.from('menu_items').select().order('id');
      categories = [for (final c in cats) MenuCategory.fromJson(c)];
      final names = {for (final c in categories) c.id: c.name};
      // Stable order: by category sort order, then name (same as the web menu).
      final order = {for (var i = 0; i < categories.length; i++) categories[i].id: i};
      menu = [for (final i in items) MenuItem.fromJson(i, names)]
        ..sort((a, b) {
          final c = (order[a.categoryId] ?? 0).compareTo(order[b.categoryId] ?? 0);
          return c != 0 ? c : a.name.toLowerCase().compareTo(b.name.toLowerCase());
        });
      menuError = null;
      // Drop cart lines for items that were removed or sold out in the meantime.
      cart.removeWhere((l) => !menu.any((m) => m.id == l.item.id && m.available));
    } catch (e) {
      menuError = friendlyError(e);
    }
    menuLoading = false;
    notifyListeners();
  }

  /// Manager only (Row Level Security rejects anyone else). Returns an error message or null.
  Future<String?> saveItem({
    int? id,
    required int categoryId,
    required String name,
    required String description,
    required double price,
    required String? imageUrl,
    required bool available,
  }) async {
    final row = {
      'category_id': categoryId,
      'name': name.trim(),
      'description': description.trim().isEmpty ? null : description.trim(),
      'price': price,
      'image_url': (imageUrl == null || imageUrl.trim().isEmpty) ? null : imageUrl.trim(),
      'is_available': available,
    };
    try {
      if (id == null) {
        await _db.from('menu_items').insert(row);
      } else {
        await _db.from('menu_items').update(row).eq('id', id);
      }
      await refreshMenu();
      return null;
    } catch (e) {
      return friendlyError(e);
    }
  }

  Future<String?> toggleAvailable(MenuItem item, bool value) async {
    try {
      await _db.from('menu_items').update({'is_available': value}).eq('id', item.id);
      item.available = value;
      if (!value) cart.removeWhere((l) => l.item == item);
      notifyListeners();
      return null;
    } catch (e) {
      return friendlyError(e);
    }
  }

  /// Same rule as the web app: items that are part of past orders are marked sold out instead of deleted.
  Future<String> deleteItem(MenuItem item) async {
    try {
      final used = await _db.from('order_items').select('id').eq('menu_item_id', item.id).limit(1);
      if (used.isNotEmpty) {
        await _db.from('menu_items').update({'is_available': false}).eq('id', item.id);
        await refreshMenu();
        return '${item.name} is part of past orders, so it was marked sold out instead of deleted.';
      }
      await _db.from('menu_items').delete().eq('id', item.id);
      await refreshMenu();
      return '${item.name} removed from the menu.';
    } catch (e) {
      return friendlyError(e);
    }
  }

  Future<String?> addCategory(String name) async {
    final n = name.trim();
    if (n.isEmpty) return 'Enter a category name.';
    try {
      final next = categories.isEmpty ? 1 : categories.map((c) => c.sortOrder).reduce((a, b) => a > b ? a : b) + 1;
      await _db.from('menu_categories').insert({'name': n, 'sort_order': next});
      await refreshMenu();
      return null;
    } catch (e) {
      return friendlyError(e);
    }
  }

  // ---------- cart (local to this device, like the web session cart) ----------
  final List<CartLine> cart = [];

  int qtyOf(MenuItem i) {
    final idx = cart.indexWhere((l) => l.item == i);
    return idx < 0 ? 0 : cart[idx].qty;
  }

  void addToCart(MenuItem i) {
    final idx = cart.indexWhere((l) => l.item == i);
    if (idx < 0) {
      cart.add(CartLine(i, 1));
    } else if (cart[idx].qty < kMaxQty) {
      cart[idx].qty++;
    }
    notifyListeners();
  }

  void removeOne(MenuItem i) {
    final idx = cart.indexWhere((l) => l.item == i);
    if (idx < 0) return;
    if (cart[idx].qty <= 1) {
      cart.removeAt(idx);
    } else {
      cart[idx].qty--;
    }
    notifyListeners();
  }

  void removeLine(MenuItem i) {
    cart.removeWhere((l) => l.item == i);
    notifyListeners();
  }

  int get cartCount => cart.fold(0, (s, l) => s + l.qty);
  double get total => r2(cart.fold(0.0, (s, l) => s + l.total));

  /// "Order again": puts the still-available items of a past order back in the cart. Returns how many were added.
  int reorder(Order o) {
    var added = 0;
    for (final l in o.lines) {
      final item = menu.where((m) => m.id == l.menuItemId && m.available).firstOrNull;
      if (item == null) continue;
      final idx = cart.indexWhere((c) => c.item == item);
      if (idx < 0) {
        cart.add(CartLine(item, l.qty.clamp(1, kMaxQty).toInt()));
      } else {
        cart[idx].qty = (cart[idx].qty + l.qty).clamp(1, kMaxQty).toInt();
      }
      added++;
    }
    notifyListeners();
    return added;
  }

  // ---------- orders ----------
  List<Order> orders = [];
  static const _orderSelect =
      '*, order_items(menu_item_id, quantity, price_at_order, menu_items(name))';

  Order? orderById(int id) => orders.where((o) => o.id == id).firstOrNull;
  List<Order> ordersWith(OrderStatus s) => orders.where((o) => o.status == s).toList().reversed.toList();

  /// The signed-in customer's own orders (newest first). Row Level Security only returns their rows anyway.
  List<Order> get myOrders => orders;

  Future<void> refreshOrders() async {
    if (_db.auth.currentUser == null) {
      // Nobody is signed in. A guest who has placed an order can still follow it.
      if (_guestId == null) {
        if (orders.isNotEmpty) {
          orders = [];
          notifyListeners();
        }
        return;
      }
      try {
        final res = await _db.rpc('get_guest_orders', params: {'p_guest_session_id': _guestId});
        orders = [for (final r in (res as List).cast<Map<String, dynamic>>()) Order.fromJson(r)];
        notifyListeners();
      } catch (_) {
        // Keep showing the last known orders; the next tick retries.
      }
      return;
    }
    try {
      final rows =
          await _db.from('orders').select(_orderSelect).order('created_at', ascending: false).limit(200);
      orders = [for (final r in rows) Order.fromJson(r)];
      notifyListeners();
    } catch (_) {
      // Keep showing the last known orders; the next tick retries.
    }
  }

  /// Places the order through a database function so prices and totals are calculated on the server.
  /// Signed-in customers use place_order(); guests (nobody signed in) use place_guest_order(),
  /// which needs no account and no Supabase "anonymous sign-ins" setting (same as the web "no login" checkout).
  /// Throws [String] with a user-friendly message on failure.
  Future<Order> placeOrder({required String name, String note = ''}) async {
    if (cart.isEmpty) throw 'Your cart is empty.';
    if (name.trim().isEmpty) throw 'Enter a name so we can call you when your order is ready.';
    try {
      final lines = [for (final l in cart) OrderLine(l.item.name, l.item.price, l.qty, menuItemId: l.item.id)];
      final items = [for (final l in cart) {'menu_item_id': l.item.id, 'quantity': l.qty}];
      final asGuest = _db.auth.currentSession == null;
      final res = asGuest
          ? await _db.rpc('place_guest_order', params: {
              'p_guest_session_id': guestId,
              'p_customer_name': name.trim(),
              'p_notes': note.trim(),
              'p_items': items,
            })
          : await _db.rpc('place_order', params: {
              'p_customer_name': name.trim(),
              'p_notes': note.trim(),
              'p_items': items,
            });
      final map = Map<String, dynamic>.from(res as Map);
      final placed = Order(
        id: (map['id'] as num).toInt(),
        number: map['order_number'] as String,
        total: (map['total'] as num).toDouble(),
        lines: lines,
        placedAt: DateTime.now(),
        customerName: name.trim(),
        customerId: profile?.id,
        note: note.trim(),
      );
      cart.clear();
      orders = [placed, ...orders.where((o) => o.id != placed.id)];
      notifyListeners();
      unawaited(refreshOrders()); // replaces the local copy with the stored one
      return placed;
    } catch (e) {
      throw friendlyError(e);
    }
  }

  /// Staff / manager only. Returns false (and changes nothing) while on break; error text via [lastActionError].
  String? lastActionError;
  Future<bool> updateOrder(int id, OrderStatus s) async {
    lastActionError = null;
    if (onBreak) {
      lastActionError = 'You are on break. Resume your shift to manage orders.';
      return false;
    }
    try {
      await _db.rpc('set_order_status', params: {'p_order_id': id, 'p_status': s.db});
      final o = orderById(id);
      if (o != null && o.status.isOpen) o.status = s; // optimistic; refresh below confirms
      notifyListeners();
      await refreshOrders();
      return true;
    } catch (e) {
      lastActionError = friendlyError(e);
      return false;
    }
  }

  // ---------- staff numbers ----------
  bool _isToday(DateTime t) {
    final n = DateTime.now();
    return t.year == n.year && t.month == n.month && t.day == n.day;
  }

  List<Order> get todaysOrders => orders.where((o) => _isToday(o.placedAt)).toList();
  int get waitingCount => ordersWith(OrderStatus.received).length;
  int get readyCount => ordersWith(OrderStatus.ready).length;
  int get activeCount => orders.where((o) => o.status == OrderStatus.preparing || o.status == OrderStatus.ready).length;
  int get soldOutCount => menu.where((m) => !m.available).length;
  double get salesToday =>
      r2(todaysOrders.where((o) => o.status != OrderStatus.cancelled).fold(0.0, (s, o) => s + o.total));
  int get cancelledToday => todaysOrders.where((o) => o.status == OrderStatus.cancelled).length;

  /// Top sellers across the loaded (recent) orders, cancelled ones excluded. Manager sales overview.
  List<MapEntry<String, int>> get topItems {
    final qty = <String, int>{};
    for (final o in orders.where((o) => o.status != OrderStatus.cancelled)) {
      for (final l in o.lines) {
        qty[l.name] = (qty[l.name] ?? 0) + l.qty;
      }
    }
    final list = qty.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return list.take(5).toList();
  }
}

/// Turns Supabase / network exceptions into a short message a customer can act on.
String friendlyError(Object e) {
  if (e is String) return e;
  if (e is AuthException) {
    final code = e.code ?? '';
    final msg = e.message;
    final low = msg.toLowerCase();
    if (code == 'invalid_credentials' || low.contains('invalid login credentials')) {
      return 'Incorrect email or password.';
    }
    if (code == 'email_not_confirmed' || low.contains('not confirmed')) {
      return 'Please confirm your email first. Check your inbox for the confirmation link.';
    }
    if (code == 'user_already_exists' || code == 'email_exists' || low.contains('already registered')) {
      return 'An account with this email already exists. Try logging in.';
    }
    if (code == 'weak_password' || low.contains('password')) {
      return 'That password is too weak. Use at least 8 characters with letters and numbers.';
    }
    if (code == 'anonymous_provider_disabled' || low.contains('anonymous')) {
      return 'Guest ordering is switched off. Please sign in or create an account.';
    }
    if (code.contains('rate_limit') || low.contains('rate limit') || low.contains('too many')) {
      return 'Too many attempts. Please wait a few minutes and try again.';
    }
    if (code == 'signup_disabled') return 'Sign-ups are switched off for this app.';
    return msg;
  }
  if (e is PostgrestException) {
    if (e.code == '42501') return 'You are not allowed to do that.';
    if (e.code == '23503') return 'That item is in use and cannot be removed.';
    if (e.code == '23505') return 'That already exists.';
    // place_order / set_order_status raise readable messages; show them as they are.
    return e.message;
  }
  final s = e.toString();
  if (s.contains('SocketException') || s.contains('ClientException') || s.contains('Failed host lookup')) {
    return 'Cannot reach the server. Check the internet connection and try again.';
  }
  return 'Something went wrong. Please try again.';
}
