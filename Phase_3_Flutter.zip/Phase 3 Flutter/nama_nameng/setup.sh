#!/usr/bin/env bash
flutter create . --project-name nama_nameng --org za.ac.cut --platforms=android,ios,web,windows
# Release builds need the INTERNET permission to reach Supabase.
M=android/app/src/main/AndroidManifest.xml
if [ -f "$M" ] && ! grep -q "android.permission.INTERNET" "$M"; then
  sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <application#' "$M"
fi
flutter pub get
echo "Done. Open this folder in VS Code and press F5."
