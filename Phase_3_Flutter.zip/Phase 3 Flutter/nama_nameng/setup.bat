@echo off
echo Setting up Nama Nameng (one-time)...
call flutter create . --project-name nama_nameng --org za.ac.cut --platforms=android,ios,web,windows
rem Release builds need the INTERNET permission to reach Supabase.
powershell -NoProfile -Command "$m='android/app/src/main/AndroidManifest.xml'; if (Test-Path $m) { $t=Get-Content $m -Raw; if ($t -notmatch 'android.permission.INTERNET') { $t=$t -replace '<application','<uses-permission android:name=\"android.permission.INTERNET\"/>`n    <application'; Set-Content $m $t } }"
call flutter pub get
echo.
echo Done. Open this folder in VS Code, pick a device (bottom-right) and press F5.
pause
