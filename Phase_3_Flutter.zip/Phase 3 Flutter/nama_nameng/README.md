# Nama Nameng (Flutter)

One mobile app, two dashboards: **Customer** and **Staff / Manager**. It uses the **same Supabase
backend as the ASP.NET web app** (project `qmcwfnupigrpkmtommcd`), so both apps share users, menu and orders:
an order placed in the app appears on the web staff board, and the other way round.

| Part | How the Flutter app does it |
|------|------------------------------|
| Login | `supabase_flutter` email + password (same accounts as the website). Guests order without any login (database functions `place_guest_order` / `get_guest_orders`, from `supabase/05_guest_orders.sql` in the ASP project). |
| Menu | reads `menu_categories` / `menu_items`; managers can add, edit, sold-out, delete (Row Level Security blocks everyone else) |
| Placing an order | `rpc('place_order')`: the server calculates prices and the total |
| Order status | `rpc('set_order_status')` (staff / manager only) |
| Live updates | Realtime on `orders`, plus a 5 second refresh as a fallback |

Rules shared with the web app: **pickup only, pay cash or card at the counter, no VAT line, no delivery**.
Statuses: `Received → Preparing → Ready → Collected` (or `Cancelled`). Roles: `Customer`, `Staff`, `Manager`.

## One-time database setup (only if not done yet)
Follow the README in the ASP.NET solution: run `supabase/01_schema.sql`, `02_seed_menu.sql`, create the staff and
manager users in the Supabase dashboard and run `03_make_staff.sql`. In Supabase > Authentication:
- turn **Confirm email OFF** while developing (otherwise new customers must click an email link before logging in)
- run `supabase/05_guest_orders.sql` (from the ASP project) once in the SQL Editor so guests can check out; "Allow anonymous sign-ins" is no longer needed

## Open and run (VS Code)
1. Install Flutter 3.22+ and the VS Code extensions *Dart* and *Flutter*.
2. **One-time setup** in this folder (adds android/ios/web/windows, adds the Android INTERNET permission, runs `pub get`):
   - Windows: double-click `setup.bat`
   - macOS / Linux: `bash setup.sh`
3. Open the folder in VS Code, pick a device (bottom-right), press **F5**.
4. Tests (no network needed): `flutter test`

The Supabase URL and the public **anon** key are in `lib/config.dart`. Never put the database password or the
`service_role` key in this app.

## Logins
| Dashboard | Login |
|-----------|-------|
| Customer | Register in the app (or on the website), or *Explore Menu* and order as a guest |
| Staff / Manager | Staff tab, e.g. `staff@namanameng.co.za` / `manager@namanameng.co.za` (the users you created in Supabase) |

## Customer dashboard
Welcome → Home (search, categories) → Menu → Cart → Checkout (name + optional note, guests allowed) → Order
Received → Track Order (live status) → Profile (edit details, order history, *Order again*, log out).

## Staff dashboard
Home (live alerts, shift timer, today's numbers; managers also see top sellers) → Incoming orders (start / cancel)
→ Order detail → Kitchen queue (ready / collected) → Menu (everyone sees it; **managers** edit, add categories, mark
sold out) → Profile (take break pauses order actions on this device, end shift = sign out).

## Folder map
`lib/config.dart` Supabase URL + anon key · `lib/models.dart` data classes matching the tables · `lib/store.dart`
all Supabase calls and shared state · `lib/theme.dart` colours · `lib/widgets.dart` shared UI · `lib/screens/`
welcome, auth, customer, checkout, staff · `test/` unit tests.

## Forgot password (customers)

Login > **Forgot password?** > enter email > Supabase emails a 6-digit code > enter the code and a new password > log in again.
It uses the same Supabase project and the same flow as the web app (`/Account/ForgotPassword`).

One-time Supabase setup (otherwise the email only contains a link and the code screen cannot be used):
change the **Reset password** email template so it shows `{{ .Token }}`. Step-by-step text to paste:
`supabase/04_password_reset_email.md` in the ASP.NET solution.

Only customer accounts can reset here; staff and manager passwords are reset by the owner in the Supabase dashboard.
Code: `lib/screens/forgot_password.dart` and `requestPasswordReset` / `resetPassword` in `lib/store.dart`.
