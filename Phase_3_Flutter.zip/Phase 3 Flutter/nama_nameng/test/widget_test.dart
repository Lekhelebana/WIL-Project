import 'package:flutter_test/flutter_test.dart';
import 'package:nama_nameng/models.dart';
import 'package:nama_nameng/store.dart';

void main() {
  MenuItem item(int id, String name, double price, {bool available = true}) => MenuItem(
      id: id, categoryId: 1, category: 'Grills', name: name, price: price, available: available);

  test('cart totals are plain item prices (no VAT, no delivery) and cap at 20 per item', () {
    final s = AppStore();
    final ribs = item(1, 'Beef Ribs', 110);
    final chips = item(2, 'Slap Chips', 30);
    s.addToCart(ribs);
    s.addToCart(ribs);
    s.addToCart(chips);
    expect(s.cartCount, 3);
    expect(s.total, 250);
    for (var i = 0; i < 30; i++) {
      s.addToCart(chips);
    }
    expect(s.qtyOf(chips), kMaxQty);
    s.removeOne(ribs);
    s.removeLine(chips);
    expect(s.total, 110);
  });

  test('menu items are the same item when the ids match (cart survives a menu refresh)', () {
    final s = AppStore();
    s.addToCart(item(1, 'Beef Ribs', 110));
    expect(s.qtyOf(item(1, 'Beef Ribs', 115)), 1);
  });

  test('order statuses match the database values', () {
    expect(OrderStatus.values.map((v) => v.db),
        ['Received', 'Preparing', 'Ready', 'Collected', 'Cancelled']);
    expect(OrderStatusX.fromDb('Ready'), OrderStatus.ready);
    expect(OrderStatus.received.label, 'New');
    expect(OrderStatus.collected.isOpen, isFalse);
  });

  test('an orders row with embedded items parses', () {
    final o = Order.fromJson({
      'id': 12,
      'order_number': 'NN-1012',
      'status': 'Preparing',
      'total': '250.00',
      'customer_name': 'Thabo',
      'notes': 'no spice',
      'created_at': '2026-10-19T08:30:00+00:00',
      'order_items': [
        {'menu_item_id': 1, 'quantity': 2, 'price_at_order': 110, 'menu_items': {'name': 'Beef Ribs'}},
        {'menu_item_id': 2, 'quantity': 1, 'price_at_order': '30.00', 'menu_items': {'name': 'Slap Chips'}},
      ],
    });
    expect(o.number, 'NN-1012');
    expect(o.status, OrderStatus.preparing);
    expect(o.total, 250);
    expect(o.lines.length, 2);
    expect(o.summary, '2× Beef Ribs, 1× Slap Chips');
  });

  test('a profile row maps the role', () {
    final p = Profile.fromJson({
      'id': 'u1', 'full_name': 'Owner', 'email': 'manager@namanameng.co.za',
      'phone': null, 'role': 'Manager', 'is_active': true,
    });
    expect(p.isStaff, isTrue);
    expect(p.isManager, isTrue);
  });

  test('reorder only adds items that are still on the menu and available', () {
    final s = AppStore();
    s.menu = [item(1, 'Beef Ribs', 110), item(2, 'Slap Chips', 30, available: false)];
    final o = Order(
        id: 1,
        number: 'NN-1001',
        placedAt: DateTime.now(),
        total: 140,
        lines: const [
          OrderLine('Beef Ribs', 110, 1, menuItemId: 1),
          OrderLine('Slap Chips', 30, 1, menuItemId: 2),
          OrderLine('Gone', 10, 1, menuItemId: 99),
        ]);
    expect(s.reorder(o), 1);
    expect(s.cartCount, 1);
  });

  test('menu items get their own picture by name, falling back to the category', () {
    String? img(String name, [String cat = 'Grills']) =>
        MenuItem(id: 1, categoryId: 1, category: cat, name: name, price: 10).image;
    expect(img('Beef Ribs'), 'assets/images/beef_ribs.jpg');
    expect(img('Chicken Wings'), 'assets/images/chicken_wings.jpg');
    expect(img('Chicken Quarter'), 'assets/images/chicken_quarter.jpg');
    expect(img('Lamb Chops'), 'assets/images/lamb_chops.jpg');
    expect(img('Boerewors'), 'assets/images/wors.jpg');
    expect(img('Slap Chips', 'Sides'), 'assets/images/chips.jpg');
    expect(img('Pap', 'Sides'), 'assets/images/pap.jpg');
    expect(img('Morogo', 'Sides'), 'assets/images/morogo.jpg');
    expect(img('Chakalaka', 'Sides'), 'assets/images/chakalaka.jpg');
    expect(img('Ginger Beer', 'Drinks'), 'assets/images/ginger_beer.jpg');
    expect(img('Still Water 500ml', 'Drinks'), 'assets/images/still_water.jpg');
    expect(img('Soft Drink 330ml', 'Drinks'), 'assets/images/soft_drink.jpg');
    expect(img('Something New', 'Grills'), 'assets/images/ribs.jpg');
    expect(img('Something New', 'Specials'), isNull);
  });
}
